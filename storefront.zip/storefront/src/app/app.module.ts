import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { CartComponent } from './cart/cart.component';
import { CategoryComponent } from './category/category.component';
import { ProductComponent } from './product/product.component';
import { CategoryService } from './category/category.service';
import { CartService } from './cart/cart.service';
import { ItemComponent } from './common/item/item.component';
import { CounterComponent } from './common/counter/counter.component';


const appRoutes: Routes = [
  {path: '', component: CategoryComponent},
  {path: 'product', component: ProductComponent},
  {path: 'cart', component: CartComponent},
  {path: '**', component: CategoryComponent },
]

@NgModule({
  declarations: [
    AppComponent,
    CartComponent,
    CategoryComponent,
    ProductComponent,
    ItemComponent,
    CounterComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes,
       { enableTracing: true} // <-- debugging purposes only
        )
  ],
  providers: [
    CategoryService,
    CartService
  ],
  exports: [RouterModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
