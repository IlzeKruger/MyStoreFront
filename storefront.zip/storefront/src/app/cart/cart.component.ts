import { Component, OnInit , OnDestroy} from '@angular/core';
import { CartService } from './cart.service';
import { CartItem } from '../models/cart.model';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit, OnDestroy {
  private items: CartItem[] = [];
  private total: number = 0;
  private cartServiceSubscription : any ;
  private itemsExist = false;

  textRight = true;

  constructor(private cartService: CartService) {
    this.items = this.cartService.getItems();
    this.total = this.cartService.getTotals();

    if (this.items.length > 0 ) {
      this.itemsExist = true;
    }
    
    const cartServiceSubscription = this.cartService.cartState$.subscribe(
      cart => {
        this.items = cart;
        this.total = this.cartService.getTotals();
    });
  }

  ngOnInit() {
  }

  onDelete($event){
    this.cartService.removeCartItem($event);
  }

  counterChanged($event, item){
    this.cartService.changeCartItem(item, $event);
  }

  ngOnDestroy(){

  }
}
