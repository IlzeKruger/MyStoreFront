import { Injectable } from '@angular/core';
import { CartItem } from '../models/cart.model';
import { Product } from '../models/product.model';
import { Subject } from 'rxjs';

@Injectable()
export class  CartService {
    private items: CartItem[] = [];
    private total: number = 0;
    private cartSubject = new Subject<any>();
    cartState$ = this.cartSubject.asObservable();

    constructor() { }

    getItems(){
        this.loadCart();
        return this.items;
    }

    getTotals(){
        // this.loadCart();
        return this.total;
    }

    getProductQuantity(title: string){
        let quantity = 1;

        if (title){
            if (localStorage.getItem('cart') != null) {
                let cart: any = JSON.parse(localStorage.getItem('cart'));
                for (var i = 0; i < cart.length; i++) {
                    let item: CartItem = JSON.parse(cart[i]);
                    if (item.product.title == title) {
                        return item.quantity;
                    }
                }
            }
        }
        return quantity;
    }

    changeCartItem(product: Product, quantity: number) {
        var title = product.title;
        if (title){
            var item: CartItem = {
                product: product,
                quantity: quantity
            };

            if (localStorage.getItem('cart') == null) {
                let cart: any = [];
                cart.push(JSON.stringify(item));
                localStorage.setItem('cart', JSON.stringify(cart));
            } else {
                let cart: any = JSON.parse(localStorage.getItem('cart'));
                let index: number = -1;
                for (var i = 0; i < cart.length; i++) {
                    let item: CartItem = JSON.parse(cart[i]);
                    if (item.product.title == title) {
                        index = i;
                        break;
                    }
                }
                if (index == -1) {
                    cart.push(JSON.stringify(item));
                    localStorage.setItem('cart', JSON.stringify(cart));
                } else {
                    let item: CartItem = JSON.parse(cart[index]);
                    item.quantity = quantity;
                    cart[index] = JSON.stringify(item);
                    localStorage.setItem("cart", JSON.stringify(cart));
                }
            }
            this.loadCart();
        }else{
            this.loadCart();
        }
	}

	loadCart() {
		this.total = 0;
		this.items = [];
		let cart = JSON.parse(localStorage.getItem('cart'));
		for (var i = 0; i < cart.length; i++) {
			let item = JSON.parse(cart[i]);
			this.items.push({
				product: item.product,
				quantity: item.quantity
			});
			this.total += item.product.price * item.quantity;
        }
        this.cartSubject.next(this.items);
	}

	removeCartItem(title: string) {
		let cart: any = JSON.parse(localStorage.getItem('cart'));
		let index: number = -1;
		for (var i = 0; i < cart.length; i++) {
			let item: CartItem = JSON.parse(cart[i]);
			if (item.product.title == title) {
				cart.splice(i, 1);
				break;
			}
		}
		localStorage.setItem("cart", JSON.stringify(cart));
        this.loadCart();
        this.cartSubject.next(this.items);
	}


}