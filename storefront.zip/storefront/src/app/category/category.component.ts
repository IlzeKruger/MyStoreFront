import { Component, OnInit } from '@angular/core';
import { CategoryService } from './category.service';
import { Product } from '../models/product.model';
import { Router } from "@angular/router";
import { CartService } from '../cart/cart.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css'],
  providers: [CartService]
})
export class CategoryComponent implements OnInit {
    private products: Product[];
    private errorMessage: string;
    private header: string;
    private headerDescription: string;
    private headerSrc: string;

    error = false;
    textRight = false;

    constructor(private categoryService: CategoryService,
                private router: Router) { }
  
    ngOnInit() {
      this.categoryService.getProducts().subscribe(
        (successResponse) => {
          this.products = successResponse;
          this.headerDescription = successResponse[0].description;
          this.header = "Plates";
          this.headerSrc = "src/media/plates-header.jpg";
        },
        (errorResponse) => {
          this.errorMessage = errorResponse.message;
          this.error = true;
          console.log('Error occurred retrieving data. Error is: ', errorResponse.message);
        }
      ) 
      console.log(this.products);
    }
  
    onSelected(product){
      console.log("I am in category " + product.title );
    }
  }
  