import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css']
})
export class CounterComponent implements OnInit {
  @Input() counter: number;
  @Output() counterEvent = new EventEmitter<number>();
  
  constructor() { }

  ngOnInit() {
  }

  increment(){
    this.counter++;
    this.counterEvent.next(this.counter);
  }

  decrement(){
    if (this.counter > 0){
      this.counter--;
      this.counterEvent.next(this.counter);
    }
  }
}
