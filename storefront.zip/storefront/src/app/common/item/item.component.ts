import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {
  @Input() product: Product;
  @Input() textRight: boolean;

  IMAGE_ROOT = "src/media/";

  constructor() { }

  ngOnInit() {
    let index = this.product.image.indexOf(this.IMAGE_ROOT)
    if (index < 0){
      this.product.image = this.IMAGE_ROOT + this.product.image;
    }
  }

}
