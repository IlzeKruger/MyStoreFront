import { Product } from './product.model';

export class CartItem {
    product: Product;
    quantity: number;

    constructor(product, quantity){
        this.product = product;
        this.quantity = quantity;
    }

}
