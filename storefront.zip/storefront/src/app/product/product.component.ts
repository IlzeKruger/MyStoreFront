import { Component, OnInit , Input} from '@angular/core';
import { Product } from '../models/product.model';
import { ActivatedRoute} from "@angular/router";
import { CartService } from '../cart/cart.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  product: Product;
  counter: number = 1;

  constructor(private route: ActivatedRoute,
              private cartService: CartService) {
  }

  onAddToCart(){
    this.cartService.changeCartItem(this.product, this.counter);
  }

  ngOnInit() {
    //The product data is passed using the queryParams when 
    //changing the route.
    this.product = <Product>this.route.snapshot.queryParams;
    this.counter = this.cartService.getProductQuantity( this.product.title);
  }

  counterChanged($event){
    this.counter = $event;
  }
}
